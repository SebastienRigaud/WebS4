window.addEventListener("load", main);

function main() {
	document.getElementById("newAlarmForm").style.display = "none";
	date = new Date();
	alarms = new Array();
	refreshTime();
	document.getElementById("addAlarm").addEventListener("click",addAlarm);
	
}

function refreshTime() {
	
	
	date.setTime(Date.now());
	document.getElementById("time").textContent = date.getHours()+":"+date.getMinutes()+":"+date.getSeconds();
	setTimeout(refreshTime, 1000);

}

function addAlarm() {
	document.getElementById("newAlarmForm").style.display = "block";
	document.getElementById("createNewAlarm").addEventListener("click",createAlarm(document.getElementById("Heures").textContent));
	
}

function createAlarm(time)
{
	alarms.push(time);
	refreshAlarmsDisplay();
}

function refreshAlarmsDisplay()
{
	document.getElementById("alarms").innerHTML = "";
	for(alarm of alarms)
	{
		document.getElementById("alarms").innerHTML += "<tr><td>"+getHeures(alarm)+"</td><td>"+getMinutes(alarm)+"</td><td>"+getSeconds(alarm)+"</tr>";
	}
}

function getHeures(time)
{
	return Math.floor(time/(60*60));
}

function getMinutes(time)
{
	return Math.floor((time-(getHeures(time)*60*60))/60);
}

function getSeconds(time)
{
	return time-getHeures(time)*60*60-getMinutes(time)*60;
}